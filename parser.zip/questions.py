import nltk
import sys
import os
import string
import math

FILE_MATCHES = 1
SENTENCE_MATCHES = 1

def main():

    # Check command-line arguments
    if len(sys.argv) != 2:
        sys.exit("Usage: python questions.py corpus")

    # Calculate IDF values across files
    files = load_files(sys.argv[1])
    file_words = {
        filename: tokenize(files[filename])
        for filename in files
    }
    file_idfs = compute_idfs(file_words)

    # Prompt user for query
    print('\n')
    query = set(tokenize(input("Query: ")))

    # Determine top file matches according to TF-IDF
    filenames = top_files(query, file_words, file_idfs, n=FILE_MATCHES)

    # Extract sentences from top files
    sentences = dict()
    for filename in filenames:
        for passage in files[filename].split("\n"):
            for sentence in nltk.sent_tokenize(passage):
                tokens = tokenize(sentence)
                if tokens:
                    sentences[sentence] = tokens

    # Compute IDF values across sentences
    idfs = compute_idfs(sentences)

    # Determine top sentence matches
    matches = top_sentences(query, sentences, idfs, n=SENTENCE_MATCHES)
    for match in matches:
        print(match)
    print('\n')


def load_files(directory):
    """
    Given a directory name, return a dictionary mapping the filename of each
    `.txt` file inside that directory to the file's contents as a string.
    """
    # Initialize dictionary and read files
    corpus = dict()
    for article in os.listdir(directory):
        with open(os.path.join(directory, article)) as file:
           corpus[file] = file.read()

    return corpus


def tokenize(document):
    """
    Given a document (represented as a string), return a list of all of the
    words in that document, in order.

    Process document by coverting all words to lowercase, and removing any
    punctuation or English stopwords.
    """
    # Tokenize and lower words
    words = nltk.word_tokenize(document.lower())
    final = list()

    for word in words:
        # Filter out punctuation and stopwords
        if word not in string.punctuation and word not in nltk.corpus.stopwords.words("english"):
            final.append(word)

    return final

def compute_idfs(documents):
    """
    Given a dictionary of `documents` that maps names of documents to a list
    of words, return a dictionary that maps words to their IDF values.

    Any word that appears in at least one of the documents should be in the
    resulting dictionary.
    """
    # Initialize IDF dictionary
    idfs = dict()

    # Loop over every document
    for document in documents:
        words = set()
        for word in documents[document]:
            # If word is unique, mark it as seen and start counting if it's found in other documents
            if word not in words:
                words.add(word)
                try:
                    idfs[word] += 1
                except KeyError:
                    idfs[word] = 1
    
    # Calculate IDF values (IDF = log(TotalDocuments / DocumentsContaining(word))
    for word in idfs:
        idfs[word] = math.log(len(documents) / idfs[word])

    return idfs


def top_files(query, files, idfs, n):
    """
    Given a `query` (a set of words), `files` (a dictionary mapping names of
    files to a list of their words), and `idfs` (a dictionary mapping words
    to their IDF values), return a list of the filenames of the the `n` top
    files that match the query, ranked according to tf-idf.
    """
    # Initialize tf-idfs
    tfidfs = dict()

    # Count words and multiply by term frequency
    for f in files:
        tfidfs[f] = 0
        for word in query:
            tfidfs[f] += files[f].count(word) * idfs[word]

    # Sort files by tf-idf values and return top result(s)
    return [key for key, value in sorted(tfidfs.items(), key=lambda x: x[1], reverse=True)][:n]


def top_sentences(query, sentences, idfs, n):
    """
    Given a `query` (a set of words), `sentences` (a dictionary mapping
    sentences to a list of their words), and `idfs` (a dictionary mapping words
    to their IDF values), return a list of the `n` top sentences that match
    the query, ranked according to idf. If there are ties, preference should
    be given to sentences that have a higher query term density.
    """
    # Create list of ranked sentences
    final = list()

    # Loop over sentences and initialize a list of ranks
    for sentence in sentences:
        ranks = [sentence, 0, 0]

        # Look for matched words in the query and selected sentence
        for word in query:
            if word in sentences[sentence]:

                # Calculate the matching word measure as the sum of IDF values
                ranks[1] += idfs[word]

                # Calculate the query term density as the proportion of relevant words
                ranks[2] += sentences[sentence].count(word) / len(sentences[sentence])

        final.append(ranks)

    # Sort the list by matching word measure and query term density
    return [s for s, mwm, qtd in sorted(final, key=lambda x: (x[1], x[2]), reverse=True)][:n]

if __name__ == "__main__":
    main()

# Created by Ethan Ali for CS50-AI
